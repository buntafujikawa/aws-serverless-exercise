'use strict';

const mysql = require('mysql');

const connection = mysql.createConnection({
  host     : process.env.DB_HOST, // EC2インスタンスのプライベートIPアドレス
  port     : process.env.DB_PORT, // 3306
  database : process.env.DB_NAME, // sample
  user     : process.env.DB_USER, // lambda_sample
  password : process.env.DB_PASS  // password
});

exports.handler = async (event, context) => {
  const sql = `SELECT name,price,created_at FROM items WHERE deleted_at IS NULL ORDER BY created_at DESC;`;

  // 接続、クエリの発行（バインド変数の値は第二引数に配列を渡す）
  await connection.query(sql, function(err, rows, fields) {
    if(err){
      context.done(null, err);
      // console.log()
      return {
        isBase64Encoded: false,
        statusCode: 500,
        headers: { 'Content-Type': 'application/json; charset=UTF-8'},
        body: [],
      };
    } else {
      return {
        isBase64Encoded: false,
        statusCode: 200,
        headers: { 'Content-Type': 'application/json; charset=UTF-8'},
        body: JSON.stringify(rows),
      };
    }

    // context.done(null, rows);
  });
};
